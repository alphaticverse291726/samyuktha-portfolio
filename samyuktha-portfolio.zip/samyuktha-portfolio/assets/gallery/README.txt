Add your gallery photos here (JPG or PNG).

Naming suggestion:
  professional-01.jpg
  events-sparc-2025.jpg
  personal-coimbatore.jpg

Then open gallery.html and add them using the REAL PHOTO TEMPLATE in the code.
