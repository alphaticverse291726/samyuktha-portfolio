Place your portrait photo here as: portrait.jpg

This file is a placeholder — delete it once you add your photo.
The home page will automatically display portrait.jpg when it is present.
