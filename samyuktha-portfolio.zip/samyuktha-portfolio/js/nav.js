// ═══════════════════════════════════════
//  H. I. Samyuktha — Portfolio · nav.js
// ═══════════════════════════════════════

const PAGES = ['home','experience','expertise','writings','achievements','events','linkedin','gallery','diary','connect'];

function goTo(page) {
  window.location.href = page + '.html';
}

function toggleTheme() {
  const current = document.documentElement.dataset.theme || 'dark';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  localStorage.setItem('theme', next);
}

function initTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.dataset.theme = saved;
}

function setActiveNav() {
  const page = window.location.pathname.split('/').pop().replace('.html','') || 'home';
  document.querySelectorAll('.nav-tab, .mobile-nav button').forEach(el => {
    const target = el.dataset.page;
    el.classList.toggle('active', target === page);
  });
}

// Scroll reveal
const obs = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.08 });

function initReveal() {
  document.querySelectorAll('.reveal, .tl-item').forEach(el => obs.observe(el));
  document.querySelectorAll('.tl-item').forEach((el, i) => { el.style.transitionDelay = (i * 0.13) + 's'; });
}

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  setActiveNav();
  initReveal();
});
