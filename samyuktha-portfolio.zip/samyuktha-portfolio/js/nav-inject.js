// ═══════════════════════════════════════════════
//  Shared nav HTML injector · nav-inject.js
// ═══════════════════════════════════════════════

function injectNav() {
  const navHTML = `
<nav>
  <a href="home.html" class="nav-brand">H. I. Samyuktha</a>
  <div class="nav-center">
    <button class="nav-tab" data-page="home"        onclick="location.href='home.html'">Home</button>
    <button class="nav-tab" data-page="experience"  onclick="location.href='experience.html'">Experience</button>
    <button class="nav-tab" data-page="expertise"   onclick="location.href='expertise.html'">Expertise</button>
    <button class="nav-tab" data-page="writings"    onclick="location.href='writings.html'">Writings</button>
    <button class="nav-tab" data-page="achievements" onclick="location.href='achievements.html'">Achievements</button>
    <button class="nav-tab" data-page="events"      onclick="location.href='events.html'">Events</button>
    <button class="nav-tab" data-page="linkedin"    onclick="location.href='linkedin.html'">LinkedIn</button>
    <button class="nav-tab" data-page="gallery"     onclick="location.href='gallery.html'">Gallery</button>
    <button class="nav-tab" data-page="diary"       onclick="location.href='diary.html'">Diary</button>
    <button class="nav-tab" data-page="connect"     onclick="location.href='connect.html'">Connect</button>
  </div>
  <button class="theme-btn" aria-label="Toggle theme" onclick="toggleTheme()"></button>
</nav>

<div class="mobile-nav">
  <button data-page="home"        onclick="location.href='home.html'">
    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>Home
  </button>
  <button data-page="experience"  onclick="location.href='experience.html'">
    <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>Work
  </button>
  <button data-page="writings"    onclick="location.href='writings.html'">
    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Write
  </button>
  <button data-page="linkedin"    onclick="location.href='linkedin.html'">
    <svg viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>LinkedIn
  </button>
  <button data-page="gallery"     onclick="location.href='gallery.html'">
    <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>Gallery
  </button>
  <button data-page="diary"       onclick="location.href='diary.html'">
    <svg viewBox="0 0 24 24"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>Diary
  </button>
  <button data-page="connect"     onclick="location.href='connect.html'">
    <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>Connect
  </button>
</div>`;

  document.body.insertAdjacentHTML('afterbegin', navHTML);
}

document.addEventListener('DOMContentLoaded', injectNav);
